
import java.util.Scanner;

public class MyBinaryHeap {
    static class Process{
        int priority, index;
        
        public  int compareTo(Process _y){
            int result = this.priority > _y.priority ?1:0;
            result = this.priority < _y.priority && result == 0?-1:result; // System.out.println( "comparados " +this.priority+" y "+_y.priority+" da: "+ result);
            return result;
        }

        public Process(int priority, int index){
            this.priority = priority;
            this.index = index;
        }
    }

    private int currentSize;                       // Number of elements in heap
    private /*AnyType*/Process  [ ] array; // The heap array
    private static final int DEFAULT_CAPACITY = 10;

    /**
     * Construct the binary heap.
     */
    public MyBinaryHeap( ) {
        this( DEFAULT_CAPACITY );
    }
    public MyBinaryHeap( int capacity ) {
        currentSize = 0;
        array = /*(AnyType[])*/ new Process[ capacity + 1 ];
    }
      // /*AnyType*/Process _
    public MyBinaryHeap( Process [ ] items )    {
            currentSize = items.length; array = /*(AnyType[])*/ new Process[ ( currentSize + 2 ) * 11 / 10 ]; int i = 1; 
            for( /*AnyType*/Process item : items )
                array[ i++] = item;
            buildHeap( );
    }
    /**  * Construct the binary heap. 
    */

      // /*AnyType*/Process _
    public void insert( Process x )    {
        if( currentSize == array.length - 1 )
            enlargeArray( array.length * 2 + 1 );
            // Percolate up
        int hole = ++currentSize;
        for( array[ 0 ] = x; x.compareTo( array[ hole / 2 ] ) < 0; hole /= 2 )
            array[ hole ] = array[ hole / 2 ];
        array[ hole ] = x;
    }

    private void enlargeArray( int newSize )    {
        /*AnyType*/Process [] old = array;
        array = /*(AnyType [])*/ new Process[ newSize ];
        for( int i = 0; i < old.length; i++ )
            array[ i ] = old[ i ];        
    }
    
      // /*AnyType*/Process _
    public Process findMin( )     {
        if( isEmpty( ) )
            System.out.println( "ERROR 91! " ); // throw new Exception( );
        return array[ 1 ];
    }

      // /*AnyType*/Process _
    public Process deleteMin( )     {

       // System.out.print("antes: ");
       //  for (int i = 1; i<=currentSize;i++ ) {
       //      System.out.print(array[i].priority+" , ");
       //  }
       //  System.out.println("");

        if( isEmpty( ) )
            System.out.println( "ERROR 104! " ); // throw new Exception( );

        /*AnyType*/Process minItem = findMin( );
        array[ 1 ] = array[ currentSize-- ];
        percolateDown( 1 );
        System.out.println("printed: "+(minItem.index+1)+" con p: "+minItem.priority);

        // System.out.print("despu: ");
        // for (int i = 1; i<=currentSize;i++ ) {
        //     System.out.print(array[i].priority+" , ");
        // }
        // System.out.println("");

        return minItem;
    }

    private void buildHeap( )    {
        for( int i = currentSize / 2; i > 0; i-- )
            percolateDown( i );
    }

    public boolean isEmpty( )    {
        return currentSize == 0;
    }

    public void makeEmpty( )    {
        currentSize = 0;
    }

    private void percolateDown( int hole )    {
        int child;
        /*AnyType*/Process tmp = array[ hole ];


             // System.out.println("");
             // System.out.println("A rpocesar "+currentSize);
             // System.out.println("");
        for( ; hole * 2 <= currentSize; hole = child ) {

            child = hole * 2;
            if( child != currentSize &&  array[ child + 1 ].compareTo( array[ child ] ) <= 0 ){
                // System.out.println("SUMADO");
                child++;
            }
             // System.out.println("hole: "+hole+" child: "+child);
            if( array[ child ].compareTo( tmp ) <= 0 ){

                // System.out.println("LLENADO HOLE");
                array[ hole ] = array[ child ];
            }
            else
                break;
        }
        array[ hole ] = tmp;


    }


        //  ************** MAIN***********************

    public static void main( String [ ] args )    {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        MyBinaryHeap h = new MyBinaryHeap( );

        for(int i = 0; i < n; i++){
            int priority = 10-scan.nextInt();
            // if (i == m) {
            //     priority ++;
            // }
            h.insert(new Process(priority, i));
        }
        

        int prints =0;
        for(int i = 0; i < n; i++ ){
            int  iPrinted = h.deleteMin().index;
             prints ++;
            if( iPrinted == m )
                break;
        }
        System.out.println(prints);

    }
}
