import java.util.*;

public class bien{
    
    
    static class Proceso{
        int prioridad;
        int indice;
        
        public Proceso(int prioridad, int indice){
            this.indice = indice;
            this.prioridad = prioridad;
        }
    }
    
    public static boolean buscar_mayor_prioridad(int _k, ArrayDeque<Proceso> _lista){
        boolean movido =false;
        for (Proceso pi : _lista ) {

            if( pi.prioridad > _k ){
                movido = true;
                _lista.addLast(_lista.removeFirst());
                break;
            }
        }      
        return movido;
    }

    public static void main(String args[] ) throws Exception {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int m = scan.nextInt();
        // ArrayDeque<Proceso> pry = new ArrayDeque<>();



        ArrayList<ArrayList<int[]>> priorities = new ArrayList<ArrayList<int[]>>();
        for(int i=0; i<10; i++){
            ArrayList<int[]> p = new ArrayList<int[]>();
            priorities.add(p);
        }

        int maxPri=0;
        int lastIndRemoved = 0;
        int priSearch=0;
        for(int i = 0; i < n; i++){
            int priRead = scan.nextInt();
            int[] process = { priRead , i };
            priorities.get(priRead).add(process);
            maxPri = priRead >= maxPri? priRead:maxPri;
            lastIndRemoved = priRead == maxPri ? i : lastIndRemoved;
            priSearch = i ==m? priRead:priSearch;
        }

        System.out.println("maxPri "+maxPri);
        System.out.println("priSearch "+priSearch);
        int prints = 0;
        int lastIndRemovedTmp =0;
        for(int i = maxPri-1; i > priSearch; i--){
            ArrayList<int[]> list = priorities.get(i);
            if (list.isEmpty())
                continue;
            prints += list.size();
            for (int[] k : list ) {
                if(k[1]<lastIndRemoved){
                    lastIndRemovedTmp = k[1];
                }else{
                    break;
                }
            }
            // lastIndRemoved = lastIndRemovedTmp  > lastIndRemoved? lastIndRemovedTmp:lastIndRemoved;
            lastIndRemoved = lastIndRemovedTmp ;
            // System.out.println("LAST "+lastIndRemoved+" TEMP: "+lastIndRemovedTmp);
                    
        }
        ArrayList<int[]> list = priorities.get(priSearch);

        // System.out.println("lastIndRemoved pre: "+lastIndRemoved);
        lastIndRemoved = maxPri == priSearch ? m:lastIndRemoved;
        // System.out.println("lastIndRemoved pos: "+lastIndRemoved+" , size se: "+list.size());

        // System.out.println("PRINTS pre "+prints);
        prints += maxPri != priSearch ? priorities.get(maxPri).size():0;
        System.out.println("PRINTS "+prints);

        int samePrioPri = 0;
        for (int[] k : list ) {

            if(maxPri == priSearch){
                
            }

            // System.out.println("indice "+k[1]);
            if( k[1] != m){
                // System.out.println("JODER "+k[1]);
                samePrioPri++;
            }else{

                // break;
            }
        }
        prints ++;
        // System.out.println("PRINTS "+prints);
        // System.out.println("samePrioritiPrints "+samePrioritiPrints);
        // prints+=(samePrioritiPrints);
        int k =0;

        System.out.println(prints);
    }
}